import { createEnv } from "@t3-oss/env-core";
import { z } from "zod";

export const env = createEnv({
  server: {
    CONVEX_SITE_URL: z.url(),
    POLAR_DEPOSIT_PRODUCT_ID: z.optional(z.string().min(1)),
    POLAR_ORGANIZATION_TOKEN: z.optional(z.string().min(1)),
    POLAR_WEBHOOK_SECRET: z.optional(z.string().min(1)),
    RESEND_API_KEY: z.optional(z.string().min(1)),
    RESEND_SENDER_EMAIL_AUTH: z.optional(z.email()),
    RESERVATION_EMAIL_MODE: z.optional(z.enum(["capture", "sent"])),
    SITE_URL: z.url(),
    AUTH_GOOGLE_ID: z.string().min(1),
    AUTH_GOOGLE_SECRET: z.string().min(1),
  },
  runtimeEnv: {
    CONVEX_SITE_URL: process.env.CONVEX_SITE_URL,
    POLAR_DEPOSIT_PRODUCT_ID: process.env.POLAR_DEPOSIT_PRODUCT_ID,
    POLAR_ORGANIZATION_TOKEN: process.env.POLAR_ORGANIZATION_TOKEN,
    POLAR_WEBHOOK_SECRET: process.env.POLAR_WEBHOOK_SECRET,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    RESEND_SENDER_EMAIL_AUTH: process.env.RESEND_SENDER_EMAIL_AUTH,
    RESERVATION_EMAIL_MODE: process.env.RESERVATION_EMAIL_MODE,
    SITE_URL: process.env.SITE_URL,
    AUTH_GOOGLE_ID: process.env.AUTH_GOOGLE_ID,
    AUTH_GOOGLE_SECRET: process.env.AUTH_GOOGLE_SECRET,
  },
  skipValidation: !process.env.VALIDATE_ENV,
});
